﻿namespace ItMarathon.Dal.Enums;

public enum PropertyDefinitionType
{
    Predefined,
    Custom
}
