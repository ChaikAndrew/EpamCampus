﻿namespace ItMarathon.Dal.Enums;

public enum PetOrigin
{
    ShelterRepresentative = 1,
    BreederOwner,
    PrivateIndividual
}